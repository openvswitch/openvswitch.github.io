# Generated automatically -- do not modify!    -*- buffer-read-only: t -*-
VERSION = "2.17.7"
