# Generated automatically -- do not modify!    -*- buffer-read-only: t -*-
# Spec file for Open vSwitch.

# Copyright (C) 2009, 2010, 2013, 2014, 2015, 2016 Nicira Networks, Inc.
#
# Copying and distribution of this file, with or without modification,
# are permitted in any medium without royalty provided the copyright
# notice and this notice are preserved.  This file is offered as-is,
# without warranty of any kind.
#
# If tests have to be skipped while building, specify the '--without check'
# option. For example:
#     rpmbuild -bb --without check rhel/openvswitch-fedora.spec
#
# Support for executing kernel data path tests under rpmbuild is
# provided, however this is intended for use only in test environments
# and should not be used otherwise (these tests require root privileges).
# These tests can be executed, for example, via:
#    rpmbuild -rb --with check_datapath_kernel openvswitch-fedora.src.rpm

# If libcap-ng isn't available and there is no need for running OVS
# as regular user, specify the '--without libcapng'
%bcond_without libcapng
# To enable DPDK support, specify '--with dpdk' when building
%bcond_with dpdk
# To disable AF_XDP support, specify '--without afxdp' when building
%bcond_without afxdp
# To control the USDT support
%bcond_without usdt

# If there is a need to automatically enable the package after installation,
# specify the "--with autoenable"
%bcond_with autoenable

# Enable PIE, bz#955181
%global _hardened_build 1

# some distros (e.g: RHEL-7) don't define _rundir macro yet
# Fedora 15 onwards uses /run as _rundir
%if 0%{!?_rundir:1}
%define _rundir /run
%endif

%{!?release_number:%define release_number 1}

Name: openvswitch
Summary: Open vSwitch
Group: System Environment/Daemons
URL: http://www.openvswitch.org/
Version: 4.0.0

# Nearly all of openvswitch is ASL 2.0.  The lib/sflow*.[ch] files are SISSL.
License: ASL 2.0 and SISSL
Release: %{release_number}%{?dist}
Source: http://openvswitch.org/releases/%{name}-%{version}.tar.gz

BuildRequires: gcc gcc-c++
BuildRequires: autoconf automake libtool
BuildRequires: systemd-units openssl openssl-devel
BuildRequires: python3-devel
BuildRequires: desktop-file-utils
BuildRequires: groff graphviz
BuildRequires: checkpolicy, selinux-policy-devel
BuildRequires: /usr/bin/sphinx-build-3
# make check dependencies
BuildRequires: procps-ng
%if %{with libcapng}
BuildRequires: libcap-ng libcap-ng-devel
Provides: user(openvswitch)
Provides: group(openvswitch)
%if %{with dpdk}
Provides: group(hugetlbfs)
%endif
%endif
%if %{with dpdk}
BuildRequires: libpcap-devel numactl-devel
BuildRequires: dpdk-devel >= 25.11
Provides: %{name}-dpdk = %{version}-%{release}
%endif
%if %{with afxdp}
BuildRequires: libxdp-devel libbpf-devel numactl-devel
%endif
%if %{with usdt}
BuildRequires: libbpf-devel systemtap-sdt-devel
%endif
BuildRequires: unbound unbound-devel

Requires: openssl hostname iproute module-init-tools unbound

Requires(pre): shadow-utils
Requires(post): /bin/sed
Requires(post): systemd-units
Requires(preun): systemd-units
Requires(postun): systemd-units
Obsoletes: openvswitch-controller <= 0:2.1.0-1

# to skip running checks, pass --without check
%bcond_without check
%bcond_with check_datapath_kernel

%description
Open vSwitch provides standard network bridging functions and
support for the OpenFlow protocol for remote per-flow control of
traffic.

%package selinux-policy
Summary: Open vSwitch SELinux policy
License: ASL 2.0
BuildArch: noarch
Requires: selinux-policy-targeted

%description selinux-policy
Tailored Open vSwitch SELinux policy

%package -n python3-openvswitch
Summary: Open vSwitch python3 bindings
License: ASL 2.0
BuildArch: noarch
Requires: python3

# DNS resolution support in Python IDL.
Suggests: python3-unbound
# Dependencies of ovs.flow library.
Suggests: python3-netaddr python3-pyparsing
# Dependencies of ovs-flowviz.
Suggests: python3-click python3-graphviz python3-rich

%{?python_provide:%python_provide python3-openvswitch = %{version}-%{release}}

%description -n python3-openvswitch
Python bindings for the Open vSwitch database

%package test
Summary: Open vSwitch testing utilities
License: ASL 2.0
BuildArch: noarch

%description test
Utilities that are useful to diagnose performance and connectivity
issues in Open vSwitch setup.

%package devel
Summary: Open vSwitch OpenFlow development package (library, headers)
License: ASL 2.0

%description devel
This provides shared library, libopenswitch.so and the openvswitch header
files needed to build an external application.

%if (0%{?rhel} > 7 && 0%{?rhel} < 9) || (0%{?fedora} > 28 && 0%{?fedora} < 41)
%package -n network-scripts-%{name}
Summary: Open vSwitch legacy network service support
License: ASL 2.0
Requires: network-scripts
Supplements: (%{name} and network-scripts)

%description -n network-scripts-%{name}
This provides the ifup and ifdown scripts for use with the legacy network
service.
%endif

%package ipsec
Summary: Open vSwitch IPsec tunneling support
License: ASL 2.0
Requires: openvswitch python3-openvswitch libreswan

%description ipsec
This package provides IPsec tunneling support for OVS tunnels.

%prep
%setup -q

%build
%configure \
%if %{with libcapng}
        --enable-libcapng \
%else
        --disable-libcapng \
%endif
%if %{with dpdk}
        --with-dpdk=shared \
%endif
%if %{with afxdp}
        --enable-afxdp \
%else
        --disable-afxdp \
%endif
%if %{with usdt}
        --enable-usdt-probes \
%endif
        --enable-ssl \
        --disable-static \
        --enable-shared \
        --with-pkidir=%{_sharedstatedir}/openvswitch/pki \
        --with-version-suffix=-%{release} \
        PYTHON3=%{__python3}

build-aux/dpdkstrip.py \
%if %{with dpdk}
        --dpdk \
%else
        --nodpdk \
%endif
        < rhel/usr_lib_systemd_system_ovs-vswitchd.service.in \
        > rhel/usr_lib_systemd_system_ovs-vswitchd.service

make %{?_smp_mflags}
make selinux-policy

%install
rm -rf $RPM_BUILD_ROOT
make install DESTDIR=$RPM_BUILD_ROOT

install -d -m 0755 $RPM_BUILD_ROOT%{_rundir}/openvswitch
install -d -m 0750 $RPM_BUILD_ROOT%{_localstatedir}/log/openvswitch
install -d -m 0755 $RPM_BUILD_ROOT%{_sysconfdir}/openvswitch

%if %{with dpdk}
install -p -D -m 0644 rhel/usr_lib_udev_rules.d_91-vfio.rules \
        $RPM_BUILD_ROOT%{_prefix}/lib/udev/rules.d/91-vfio.rules
%endif

install -p -D -m 0644 \
        rhel/usr_share_openvswitch_scripts_systemd_sysconfig.template \
        $RPM_BUILD_ROOT/%{_sysconfdir}/sysconfig/openvswitch
for service in openvswitch ovsdb-server ovs-vswitchd ovs-delete-transient-ports \
                openvswitch-ipsec; do
        install -p -D -m 0644 \
                        rhel/usr_lib_systemd_system_${service}.service \
                        $RPM_BUILD_ROOT%{_unitdir}/${service}.service
done
install -p -D -m 0644 \
        rhel/usr_lib_systemd_system_ovsdb-server.socket \
        $RPM_BUILD_ROOT%{_unitdir}/ovsdb-server.socket
install -m 0755 rhel/etc_init.d_openvswitch \
        $RPM_BUILD_ROOT%{_datadir}/openvswitch/scripts/openvswitch.init

install -p -D -m 0644 rhel/etc_openvswitch_default.conf \
        $RPM_BUILD_ROOT/%{_sysconfdir}/openvswitch/default.conf

install -p -D -m 0644 rhel/etc_logrotate.d_openvswitch \
        $RPM_BUILD_ROOT/%{_sysconfdir}/logrotate.d/openvswitch

install -m 0644 vswitchd/vswitch.ovsschema \
        $RPM_BUILD_ROOT/%{_datadir}/openvswitch/vswitch.ovsschema

install -d -m 0755 $RPM_BUILD_ROOT/%{_sysconfdir}/sysconfig/network-scripts/

%if ! (0%{?rhel} >= 9 || 0%{?fedora} >= 41)
install -p -m 0755 rhel/etc_sysconfig_network-scripts_ifdown-ovs \
        $RPM_BUILD_ROOT/%{_sysconfdir}/sysconfig/network-scripts/ifdown-ovs
install -p -m 0755 rhel/etc_sysconfig_network-scripts_ifup-ovs \
        $RPM_BUILD_ROOT/%{_sysconfdir}/sysconfig/network-scripts/ifup-ovs
%endif

install -d -m 0755 $RPM_BUILD_ROOT%{python3_sitelib}
cp -a $RPM_BUILD_ROOT/%{_datadir}/openvswitch/python/* \
   $RPM_BUILD_ROOT%{python3_sitelib}

mv $RPM_BUILD_ROOT%{python3_sitelib}/ovs/flowviz/ovs-flowviz \
   $RPM_BUILD_ROOT/%{_bindir}/ovs-flowviz

rm -rf $RPM_BUILD_ROOT/%{_datadir}/openvswitch/python/

install -d -m 0755 $RPM_BUILD_ROOT/%{_sharedstatedir}/openvswitch

touch $RPM_BUILD_ROOT%{_sysconfdir}/openvswitch/system-id.conf

install -p -m 644 -D selinux/openvswitch-custom.pp \
        $RPM_BUILD_ROOT%{_datadir}/selinux/packages/%{name}/openvswitch-custom.pp

install -d $RPM_BUILD_ROOT%{_prefix}/lib/firewalld/services/

install -p -D -m 0755 \
        rhel/usr_share_openvswitch_scripts_ovs-systemd-reload \
        $RPM_BUILD_ROOT%{_datadir}/openvswitch/scripts/ovs-systemd-reload

# Remove .la files, if present (automatic with %__brp_remove_la_files on f36+).
rm -f $RPM_BUILD_ROOT%{_libdir}/*.la

%check
%if %{with check}
    touch resolv.conf
    export OVS_RESOLV_CONF=$(pwd)/resolv.conf
    if make check TESTSUITEFLAGS='%{_smp_mflags}' RECHECK=yes; then :;
    else
        cat tests/testsuite.log
        exit 1
    fi
%endif
%if %{with check_datapath_kernel}
    if make check-kernel RECHECK=yes; then :;
    else
        cat tests/system-kmod-testsuite.log
        exit 1
    fi
%endif

%clean
rm -rf $RPM_BUILD_ROOT

%pre selinux-policy
%selinux_relabel_pre -s targeted

%preun
%if 0%{?systemd_preun:1}
    %systemd_preun %{name}.service
%else
    if [ $1 -eq 0 ] ; then
        # Package removal, not upgrade
        /bin/systemctl --no-reload disable %{name}.service >/dev/null 2>&1 || :
        /bin/systemctl stop %{name}.service >/dev/null 2>&1 || :
    fi
%endif

%pre
%if %{with libcapng}
getent group openvswitch >/dev/null || groupadd -r openvswitch
getent passwd openvswitch >/dev/null || \
    useradd -r -g openvswitch -d / -s /sbin/nologin \
    -c "Open vSwitch Daemons" openvswitch

%if %{with dpdk}
    getent group hugetlbfs >/dev/null || groupadd -r hugetlbfs
    usermod -a -G hugetlbfs openvswitch
%endif
%endif

%if %{with autoenable}
    if [ -x "/etc/init.d/openvswitch" ]; then
        touch %{_tmppath}/ovs-upgrade-from-sysv
    fi
%endif
exit 0

%post
%if %{with libcapng}
if [ $1 -eq 1 ]; then
%if %{with dpdk}
    %define gname hugetlbfs
%else
    %define gname openvswitch
%endif
    sed -i \
        's@^#OVS_USER_ID="openvswitch:openvswitch"@OVS_USER_ID="openvswitch:%{gname}"@'\
        %{_sysconfdir}/sysconfig/openvswitch
    sed -i 's:\(.*su\).*:\1 openvswitch %{gname}:' %{_sysconfdir}/logrotate.d/openvswitch

    # In the case of upgrade, this is not needed
    chown -R openvswitch:openvswitch %{_sysconfdir}/openvswitch
    chown -R openvswitch:%{gname} %{_localstatedir}/log/openvswitch
fi
%endif

# Ensure that /etc/openvswitch/conf.db links to /var/lib/openvswitch,
# moving an existing file if there is one.
#
# Ditto for .conf.db.~lock~.
for base in conf.db .conf.db.~lock~; do
    new=/var/lib/openvswitch/$base
    old=/etc/openvswitch/$base
    if test -f $old && test ! -e $new; then
        mv $old $new
    fi
    if test ! -e $old && test ! -h $old; then
        ln -s $new $old
    fi
done

%if 0%{?systemd_post:1}
    # This may not enable openvswitch service or do daemon-reload.
    %systemd_post %{name}.service
%else
    # Package install, not upgrade
    if [ $1 -eq 1 ]; then
        /bin/systemctl daemon-reload >/dev/null || :
    fi
%endif

%if %{with autoenable}
    systemctl daemon-reload
    systemctl enable openvswitch
    # Handle upgrades to this package from the OVS repo's rhel packages.
    # One "restart" is needed for newer systemd files to see the old running
    # daemons. Another "restart" (outside the package postinst script) is
    # needed to actually run new daemons.
    if [ -e "%{_tmppath}/ovs-upgrade-from-sysv" ]; then
        systemctl restart openvswitch
        rm "%{_tmppath}/ovs-upgrade-from-sysv"
    fi
%endif

%post selinux-policy
%selinux_modules_install -s targeted %{_datadir}/selinux/packages/%{name}/openvswitch-custom.pp

%postun
%if 0%{?systemd_postun:1}
    %systemd_postun %{name}.service
%else
    /bin/systemctl daemon-reload >/dev/null 2>&1 || :
%endif

%postun selinux-policy
if [ $1 -eq 0 ] ; then
  %selinux_modules_uninstall -s targeted openvswitch-custom
fi

%posttrans selinux-policy
%selinux_relabel_post -s targeted

%files selinux-policy
%defattr(-,root,root)
%{_datadir}/selinux/packages/%{name}/openvswitch-custom.pp

%files -n python3-openvswitch
%{_bindir}/ovs-flowviz
%{_mandir}/man8/ovs-flowviz.8*
%{python3_sitelib}/ovs

%files test
%{_bindir}/ovs-pcap
%{_bindir}/ovs-tcpdump
%{_bindir}/ovs-tcpundump
%{_datadir}/openvswitch/scripts/usdt/*
%{_mandir}/man1/ovs-pcap.1*
%{_mandir}/man8/ovs-tcpdump.8*
%{_mandir}/man1/ovs-tcpundump.1*

%files devel
%{_libdir}/lib*.so
%{_libdir}/pkgconfig/*.pc
%{_includedir}/openvswitch/*
%{_includedir}/openflow/*

%if (0%{?rhel} > 7 && 0%{?rhel} < 9) || (0%{?fedora} > 28 && 0%{?fedora} < 41)
%files -n network-scripts-%{name}
%{_sysconfdir}/sysconfig/network-scripts/ifup-ovs
%{_sysconfdir}/sysconfig/network-scripts/ifdown-ovs
%endif

%files
%if %{with libcapng}
%defattr(-,openvswitch,openvswitch)
%else
%defattr(-,root,root)
%endif
%dir %{_sysconfdir}/openvswitch
%{_sysconfdir}/openvswitch/default.conf
%config %ghost %{_sharedstatedir}/openvswitch/conf.db
%ghost %{_sharedstatedir}/openvswitch/.conf.db.~lock~
%config %ghost %{_sysconfdir}/openvswitch/system-id.conf
%config(noreplace) %{_sysconfdir}/sysconfig/openvswitch
%defattr(-,root,root)
%{_sysconfdir}/bash_completion.d/ovs-appctl-bashcomp.bash
%{_sysconfdir}/bash_completion.d/ovs-vsctl-bashcomp.bash
%config(noreplace) %{_sysconfdir}/logrotate.d/openvswitch
%{_unitdir}/openvswitch.service
%{_unitdir}/ovsdb-server.service
%{_unitdir}/ovsdb-server.socket
%{_unitdir}/ovs-vswitchd.service
%{_unitdir}/ovs-delete-transient-ports.service
%{_datadir}/openvswitch/scripts/openvswitch.init
%if ! (0%{?rhel} > 7 || 0%{?fedora} > 28)
%{_sysconfdir}/sysconfig/network-scripts/ifup-ovs
%{_sysconfdir}/sysconfig/network-scripts/ifdown-ovs
%endif
%{_datadir}/openvswitch/scripts/ovs-check-dead-ifs
%{_datadir}/openvswitch/scripts/ovs-lib
%{_datadir}/openvswitch/scripts/ovs-save
%{_datadir}/openvswitch/scripts/ovs-vtep
%{_datadir}/openvswitch/scripts/ovs-ctl
%{_datadir}/openvswitch/scripts/ovs-kmod-ctl
%{_datadir}/openvswitch/scripts/ovs-systemd-reload
%config %{_datadir}/openvswitch/local-config.ovsschema
%config %{_datadir}/openvswitch/vswitch.ovsschema
%config %{_datadir}/openvswitch/vtep.ovsschema
%{_bindir}/ovs-appctl
%{_bindir}/ovs-docker
%{_bindir}/ovs-dpctl
%{_bindir}/ovs-dpctl-top
%{_bindir}/ovs-ofctl
%{_bindir}/ovs-vsctl
%{_bindir}/ovsdb-client
%{_bindir}/ovsdb-tool
%{_bindir}/ovs-testcontroller
%{_bindir}/ovs-pki
%{_bindir}/vtep-ctl
%{_libdir}/lib*.so.*
%{_sbindir}/ovs-vswitchd
%{_sbindir}/ovsdb-server
%{_mandir}/man1/ovsdb-client.1*
%{_mandir}/man1/ovsdb-server.1*
%{_mandir}/man1/ovsdb-tool.1*
%{_mandir}/man5/ovsdb-server.5*
%{_mandir}/man5/ovsdb.local-config.5*
%{_mandir}/man5/ovs-vswitchd.conf.db.5*
%{_mandir}/man5/ovsdb.5*
%{_mandir}/man5/vtep.5*
%{_mandir}/man7/ovs-actions.7*
%{_mandir}/man7/ovs-fields.7*
%{_mandir}/man7/ovsdb.7*
%{_mandir}/man7/ovsdb-server.7*
%{_mandir}/man8/vtep-ctl.8*
%{_mandir}/man8/ovs-appctl.8*
%{_mandir}/man8/ovs-ctl.8*
%{_mandir}/man8/ovs-dpctl.8*
%{_mandir}/man8/ovs-dpctl-top.8*
%{_mandir}/man8/ovs-kmod-ctl.8*
%{_mandir}/man8/ovs-ofctl.8*
%{_mandir}/man8/ovs-pki.8*
%{_mandir}/man8/ovs-vsctl.8*
%{_mandir}/man8/ovs-vswitchd.8*
%{_mandir}/man8/ovs-testcontroller.8*
%if %{with dpdk}
%{_prefix}/lib/udev/rules.d/91-vfio.rules
%endif
%doc NOTICE README.rst NEWS rhel/README.RHEL.rst
%if %{with dpdk}
%attr(750,openvswitch,hugetlbfs) /var/lib/openvswitch
%else
%attr(750,openvswitch,openvswitch) /var/lib/openvswitch
%endif
%attr(750,root,root) /var/log/openvswitch
%ghost %attr(755,root,root) %{_rundir}/openvswitch
%ghost %attr(644,root,root) %{_rundir}/openvswitch.useropts

%files ipsec
%{_datadir}/openvswitch/scripts/ovs-monitor-ipsec
%{_unitdir}/openvswitch-ipsec.service

%changelog
* Wed Jan 12 2011 Ralf Spenneberg <ralf@os-s.net>
- First build on F14
