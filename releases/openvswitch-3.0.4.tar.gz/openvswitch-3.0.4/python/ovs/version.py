# Generated automatically -- do not modify!    -*- buffer-read-only: t -*-
VERSION = "3.0.4"
